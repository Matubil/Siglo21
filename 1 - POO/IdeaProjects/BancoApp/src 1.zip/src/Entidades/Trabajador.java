package Entidades;

public class Trabajador extends Persona {
    private String cargo;
    private String puesto;

    public Trabajador(String nombre, String apellido, String dni, String cargo, String puesto) {
        super(nombre, apellido, dni);
        this.cargo = cargo;
        this.puesto = puesto;
    }

    public String getCargo() { return cargo; }
    public void setCargo(String cargo) { this.cargo = cargo; }

    public String getPuesto() { return puesto; }
    public void setPuesto(String puesto) { this.puesto = puesto; }

    @Override
    public String toString() {
        return "Trabajador: " + getNombre() + " " + getApellido() + ", DNI: " + getDni() +
                ", Cargo: " + cargo + ", Puesto: " + puesto;
    }
}
