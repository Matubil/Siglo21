package Main;

import Banco.Banco;

public class  Main {
    public static void main(String[] args) {
        Banco banco = new Banco();
        banco.mostrarMenu();
    }
}
