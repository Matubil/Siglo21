package com.app.modelo.atencionalpublico;

public interface InfoContacto {
    String obtenerInformacion();
    String getTelefono();
}
