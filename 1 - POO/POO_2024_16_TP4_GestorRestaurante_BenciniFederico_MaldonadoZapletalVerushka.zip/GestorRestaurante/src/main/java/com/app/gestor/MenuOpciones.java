package com.app.gestor;

public interface MenuOpciones {
    String obtenerMenuOpciones();
    void procesarOpcion(int opcion);
}
